using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParserDrone_ModeSwitchMono : MonoBehaviour
{
    public FlyMode m_defaultMode;
    public FlyMode m_current;
    public enum FlyMode { Easy, RC, RCPro}
    public Eloi.PrimitiveUnityEvent_Bool m_easyMode;
    public Eloi.PrimitiveUnityEvent_Bool m_rcMode;
    public Eloi.PrimitiveUnityEvent_Bool m_rcProMode;


    public void Awake()
    {
        SetAs(m_defaultMode);
    }

    public void TryToParseAsAction(string message) {
        //Debug.Log("Fuck boy : " + message);
        message = message.Trim().ToLower();
            //if (message.IndexOf("mode:")==0)
            //    message = message.Substring("mode:".Length);
            if (message.IndexOf("rc ") >-1)
            {
                SetAs(FlyMode.RC);
            }
            if (message.IndexOf("rcpro ") > -1
                || message.IndexOf("rc pro ") > -1)
            {
                SetAs(FlyMode.RCPro);
            }
            if (message.IndexOf("goto ") > -1
                || message.IndexOf("go to ") > -1
                || message.IndexOf("easy ") > -1
                || message.IndexOf("noob ") > -1)
            {
                SetAs(FlyMode.Easy);
            }

    }

    private void SetAs(FlyMode mode)
    {
        m_current = mode;
        m_easyMode.Invoke(mode== FlyMode.Easy);
        m_rcMode.Invoke(mode == FlyMode.RC); 
        m_rcProMode.Invoke(mode == FlyMode.RCPro);
    }
}
