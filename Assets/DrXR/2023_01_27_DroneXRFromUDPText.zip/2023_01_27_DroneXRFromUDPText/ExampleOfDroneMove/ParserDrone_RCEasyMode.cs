using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParserDrone_RCEasyMode : MonoBehaviour
{
    public RCEasyMoveControllerMono m_objectToMove;

    public string[] split ;
    public float leftRight, backForward, rotateLeftRight, downUp;
    public void TryToParse(string message)
    {
        message = message.ToLower().Trim();
        while (message.IndexOf("  ") > -1) { 
            message = message.Replace("  ", " ");
        }

        // rc  leftright backForward rotateleftright downup
        // rc -1 1 0 0
        if (message.IndexOf("rc ") == 0)
        {
            split = message.Split(" ");

            leftRight = 0; backForward = 0; rotateLeftRight = 0; downUp = 0;
            if (split.Length >= 2)
                float.TryParse(split[1], out leftRight);
            if (split.Length >= 3)
                float.TryParse(split[2], out backForward);
            if (split.Length >= 4)
                float.TryParse(split[3], out rotateLeftRight);
            if (split.Length >= 5)
                float.TryParse(split[4], out downUp);


            m_objectToMove.SetHorizontaMove(leftRight);
            m_objectToMove.SetVerticalMove(downUp);
            m_objectToMove.SetFrontalMove(backForward);
            m_objectToMove.SetHorizontalRotation(rotateLeftRight);
        }

        if (message.IndexOf("rcf ") == 0)
        {
            string cmd= message.Replace("rcf ", "").Trim().ToLower();
            leftRight = 0; backForward = 0; rotateLeftRight = 0; downUp = 0;
            if (cmd.Length == 8)
            {
                if (float.TryParse(cmd.Substring(0, 2), out float lr))
                {
                    leftRight = ((lr *2f / 99f)) - 1f;  
                }
                if (float.TryParse(cmd.Substring(2, 2), out float bf))
                {
                    backForward = ((bf * 2f / 99f) ) - 1f;
                }
                if (float.TryParse(cmd.Substring(4, 2), out float lrr))
                {
                    rotateLeftRight = ((lrr * 2f / 99f) ) - 1f;
                }
                if (float.TryParse(cmd.Substring(6, 2), out float dt))
                {
                    downUp = ((dt * 2f / 99f) ) - 1f;
                }
            }


            m_objectToMove.SetHorizontaMove(leftRight);
            m_objectToMove.SetVerticalMove(downUp);
            m_objectToMove.SetFrontalMove(backForward);
            m_objectToMove.SetHorizontalRotation(rotateLeftRight);
        }

        if (message.IndexOf("rcspeed ") == 0)
        {

            split = message.Split(" ");

            leftRight = 0f; backForward = 0f; rotateLeftRight = 0f; downUp = 0;

            if (split.Length == 2)
            {

                if (float.TryParse(split[1], out float globalSpeed))
                {
                    leftRight = globalSpeed;
                    backForward = globalSpeed;
                    rotateLeftRight = globalSpeed;
                    downUp = globalSpeed;
                }

            }
            else { 
           
            if (split.Length >= 2)
                float.TryParse(split[1], out leftRight);
            if (split.Length >= 3)
                float.TryParse(split[2], out backForward);
            if (split.Length >= 4)
                float.TryParse(split[3], out rotateLeftRight);
            if (split.Length >= 5)
                float.TryParse(split[4], out downUp);
            }


            m_objectToMove.SetHorizontaMoveSpeedPercent(leftRight);
            m_objectToMove.SetVerticalMoveSpeedPercent(downUp);
            m_objectToMove.SetFrontalMoveSpeedPercent(backForward);
            m_objectToMove.SetHorizontalRotationSpeedPercent(rotateLeftRight);
        }
    }
}
