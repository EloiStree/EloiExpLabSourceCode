using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParserDrone_ChoosePlayerName : MonoBehaviour
{
    public Eloi.PrimitiveUnityEvent_String m_onPlayerNameFound;
    public void TryToParse(string message)
    {
        message = message.ToLower().Trim();
        if (message.IndexOf("name:") == 0)
        {

            message = message.Replace("name:", "");
            m_onPlayerNameFound.Invoke(message);
        }
    }
}
