using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParserDrone_GoToLocalPosition : MonoBehaviour
{
    public StraightDroneMovementMono m_moveController;

    public string[] split;
    public float leftRight, backForward,  downUp;


    public void TryToParse(string message)
    {
        message = message.ToLower().Trim();
        while (message.IndexOf("  ") > -1)
            message.Replace("  ", " ");

        if (message.IndexOf("go to ") == 0 ||
            message.IndexOf("goto ") == 0)
        {
            message = message.Replace("go to ", "").Replace("goto ", "");

            string[] split = message.Split(" ");
            float leftRight = 0, backForward = 0 , downUp = 0;
            if (split.Length >= 1)
                float.TryParse(split[0], out leftRight);
            if (split.Length >= 2)
                float.TryParse(split[1], out downUp);
            if (split.Length >= 3)
                float.TryParse(split[2], out  backForward);


            m_moveController.GoToFromCenter(new Vector3(leftRight, downUp, backForward));

        }
        //Change the distance per second wanted for the drone speed
        //GoTospeed 10mm  
        //GoTospeed 30cm
        if ( message.IndexOf("gotospeed ")==0) {
            message = message.Replace("gotospeed ", "").Trim();
            if (float.TryParse(message, out float speedPercent)) { 
                m_moveController.SetMoveSpeed(speedPercent);
            }
            
        }
    }
}