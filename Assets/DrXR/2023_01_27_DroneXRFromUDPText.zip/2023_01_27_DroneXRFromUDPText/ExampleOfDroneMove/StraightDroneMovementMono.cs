using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StraightDroneMovementMono : MonoBehaviour
{

    public Transform m_droneRoot;
    public Vector3 m_wantedDestination;
    public Quaternion m_wantedRotation;

    public float m_movingSpeedMeterPerSecond=2;
    [Range(0,1)]
    public float m_movingSpeedPercent=0.5f;

    public float m_testmagnitude;

    public void Update()
    {
        Vector3 moveDirection = m_wantedDestination - m_droneRoot.localPosition;
        Vector3 deltaDirection = moveDirection.normalized * (m_movingSpeedMeterPerSecond * m_movingSpeedPercent) * Time.deltaTime;
        m_testmagnitude = moveDirection.normalized.magnitude;

        if (moveDirection.magnitude< deltaDirection.magnitude )
        {
            m_droneRoot.localPosition = m_wantedDestination;
        }
        else {
            m_droneRoot.localPosition += deltaDirection;
        }

        m_droneRoot.localRotation = Quaternion.Lerp(m_droneRoot.localRotation, m_wantedRotation, Time.deltaTime);
    }

    private void Awake()
    {
        Refresh();
    }
    //public void 
    [ContextMenu("Refesh")]
    public void Refresh() {
        GoToFromCenter(m_wantedDestination);
    }

    public void GoToFromCenter(Vector3 whereToGoGlobal) {
        Vector3 currentRotation= m_droneRoot.localPosition; 
        m_wantedDestination = whereToGoGlobal;
        Vector3 dir = m_wantedDestination - currentRotation;
        dir.y = 0;
        m_wantedRotation =Quaternion.LookRotation(dir, m_droneRoot.up);
    }

    public void SetMoveSpeed(float speedPercent)
    {
        m_movingSpeedPercent = speedPercent;
    }

    private void OnValidate()
    {
        SetMoveSpeed(m_movingSpeedPercent);
        Refresh();
    }
}
