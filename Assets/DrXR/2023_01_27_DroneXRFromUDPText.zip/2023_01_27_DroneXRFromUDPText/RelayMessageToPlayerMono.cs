using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using UnityEngine;

public class RelayMessageToPlayerMono : MonoBehaviour
{
    public GameObject m_playerIpPrefab;
    public Transform m_parent;
    public Vector3 m_localPosition = Vector3.up;

    public Dictionary<string, GameObject> m_playerCreated = new Dictionary<string, GameObject>();
    public Dictionary<string, RelayPlayerIpMessageMono> m_playerCreatedRelay = new Dictionary<string, RelayPlayerIpMessageMono>();
    public Dictionary<string, PlayerIpLinkMono> m_udpIpPlayerInGame = new Dictionary<string, PlayerIpLinkMono>();


    public void PushMessageToPlayerDrone(string playerId, string playerMessage) {
        PushMessageToPlayerDrone(new PlayerReceivedMessage(playerId, playerMessage));
    }

    public void PushMessageToPlayerDrone(PlayerReceivedMessage playerMessage) {


        if (playerMessage.m_unicodeText.IndexOf("multi") == 0) {
            string msg = playerMessage.m_unicodeText;
            int firstWhiteSpace = msg.IndexOf(" ");
            msg = msg.Substring(firstWhiteSpace);
            int secondWhiteSpace = msg.IndexOf(" ");
            msg = msg.Substring(0, secondWhiteSpace);
            Debug.Log("MSG:" + msg);
        }

        if (!m_playerCreated.ContainsKey(playerMessage.m_playerUniqueid))
        {
            GameObject gamo = GameObject.Instantiate(m_playerIpPrefab);
            gamo.transform.parent = m_parent.transform; 

            gamo.name = ("Player: " + playerMessage.m_playerUniqueid);
            if (IPAddress.TryParse(playerMessage.m_playerUniqueid, out IPAddress address))
            {
                PlayerIpLinkMono playerip = gamo.GetComponent<PlayerIpLinkMono>();
                playerip.m_linkedIpOfDrone = playerMessage.m_playerUniqueid;
                m_udpIpPlayerInGame.Add(playerMessage.m_playerUniqueid, playerip);
            }

            PlayerUniqueGivenIdMono playerid = gamo.GetComponent<PlayerUniqueGivenIdMono>();
            playerid.m_serverGivenId = playerMessage.m_playerUniqueid;

            //PlayerUniqueGivenIdMono playerid = gamo.GetComponent<PlayerUniqueGivenIdMono>();
            //playerid.m_serverGivenId = playerMessage.m_playerUniqueid;

            RelayPlayerIpMessageMono relay = gamo.GetComponent<RelayPlayerIpMessageMono>();
            relay.Push(playerMessage);
            m_playerCreated.Add(playerMessage.m_playerUniqueid, gamo);
            m_playerCreatedRelay.Add(playerMessage.m_playerUniqueid, relay);
            gamo.transform.localPosition = m_localPosition;
        }
        else
        {
            m_playerCreatedRelay[playerMessage.m_playerUniqueid].Push(playerMessage);
        }

    }

    public  void GetAllIpInGame(out List<string> ips)
    {
        ips = m_udpIpPlayerInGame.Keys.ToList();
    }

    internal void GetAllPlayersInGame(out List<GameObject> playerDrones)
    {
        playerDrones = m_playerCreated.Values.ToList();
    }

    internal GameObject GetDroneGameObject(string ip)
    {
        throw new NotImplementedException();
    }
}

