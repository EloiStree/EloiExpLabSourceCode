using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerIpLinkMono : MonoBehaviour
{
    public string m_linkedIpOfDrone;


}
