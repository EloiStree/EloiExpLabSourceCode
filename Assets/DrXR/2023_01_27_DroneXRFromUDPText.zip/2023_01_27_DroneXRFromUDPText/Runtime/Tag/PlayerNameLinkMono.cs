using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerNameLinkMono : MonoBehaviour
{
    public string m_name;
   
}
