using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UdpToClients_SendDronePositionMono : MonoBehaviour
{
    public RelayMessageToPlayerMono m_playerInGame;
    public float m_sendPersonnalPositionDelay = 0.1f;
    public float m_sendAllDronePositionDelay = 0.2f;

    private void Start()
    {
        InvokeRepeating("SendNewsOfPlayerPosition", 0, m_sendPersonnalPositionDelay);
        InvokeRepeating("SendNewsOfAllDronePositionToEveryPlayers", 0, m_sendPersonnalPositionDelay);
    }

    
    public void SendNewsOfPlayerPosition()
    {

        m_playerInGame.GetAllIpInGame(out List<string> ips);
        foreach (var ip in ips)
        {
            Eloi.E_DateTime.GetTimestamp(out long time, true);
            Transform playerDrone = m_playerInGame.GetDroneGameObject(ip).transform;
            string cmd = string.Format("YourXRDrone|{10}|{0} {1} {2} {3} {4} {5} {6} {7} {8} |{9}",
                   playerDrone.localPosition.x,
                   playerDrone.localPosition.y,
                   playerDrone.localPosition.z,
                   0f,
                   playerDrone.localRotation.x,
                   playerDrone.localRotation.y,
                   playerDrone.localRotation.z,
                   playerDrone.localRotation.w,
                   0f,
                   time,
                   Time.frameCount);

            UDPRelayToPlayersInGameSingleton.PushMessageToPlayersUDPWithInstanceInScene(cmd);
        }
    }
    public void SendNewsOfAllDronePositionToEveryPlayers()
    {
        m_playerInGame.GetAllIpInGame(out List<string> ips);
        m_playerInGame.GetAllPlayersInGame(out List<GameObject> dronesPlayer);
        List<string> udpCallBackToSent = new List<string>();
        foreach (var drone in dronesPlayer)
        {
            PlayerUniqueGivenIdMono uniqueId = drone.GetComponent<PlayerUniqueGivenIdMono>();
            Transform dronePosition = drone.transform;
            Eloi.E_DateTime.GetTimestamp(out long time, true);
           
            string cmd = string.Format("XRDronePosition|{9}|{8}|{0:0.000} {1:0.000} {2:0.000} {3:0.000} {4:0.000} {5:0.000} {6:0.000}|{7}",
                   dronePosition.localPosition.x,
                   dronePosition.localPosition.y,
                   dronePosition.localPosition.z,
                   dronePosition.localRotation.x,
                   dronePosition.localRotation.y,
                   dronePosition.localRotation.z,
                   dronePosition.localRotation.w,
                   time,
                   uniqueId.m_serverGivenId,
                   Time.frameCount
                   );
            udpCallBackToSent.Add(cmd);
        }
        foreach (var cmd in udpCallBackToSent)
        {

            UDPRelayToPlayersInGameSingleton.PushMessageToPlayersUDPWithInstanceInScene(cmd);
        }



    }
}
