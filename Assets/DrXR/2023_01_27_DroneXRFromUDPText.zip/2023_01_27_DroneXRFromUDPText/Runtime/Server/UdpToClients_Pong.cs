using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Net;
using System.Text;
using UnityEngine;
using UDPPusherOmiDLL;

public class UdpToClients_Pong : MonoBehaviour
{
    public RelayMessageToPlayerMono m_playerInGame;


    private void Start()
    {
        InvokeRepeating("Pong", 0, 5);
    }
    void Pong() {

        m_playerInGame.GetAllIpInGame(out List<string> ips)
            ;
        DroneUDPToClients.SendUdp("Pong", ips.ToArray());
    }
}


public class DroneUDPToClients {

    public static int m_defaultPort = 2508;
    public static UDPPusher m_pusher=new UDPPusher("127.0.0.1",2508);
    public static void SendUdp( string message, params string[] ips )
    {
        foreach (var ip in ips)
        {
            m_pusher.SetWith(ip, m_defaultPort);
            m_pusher.SendMessageWithUDP(message);
        }
    }

    public static void SendUdp(string ip, string message)
    {
        m_pusher.SetWith(ip, m_defaultPort);
        m_pusher.SendMessageWithUDP(message);
    }

    public class UDPPusher
    {
        UDPTargetParams m_target;
        IPEndPoint m_destinationEndPoint;
        Socket m_destinationSock;


        public UDPTargetParams GetCurrentTarget() { return m_target; }

        public UDPPusher()
        {
            m_target = new UDPTargetParams();
            SetWith(m_target);
        }
        public UDPPusher(string adddres, int port)
        {
            m_target = new UDPTargetParams();
            m_target.SetWith(adddres, port);
            SetWith(m_target);
        }


        public void SetWith(in string address, int port)
        {
            m_target.SetWith(address, port);
            SetWith(m_target);

        }
        public void SetWith(UDPTargetParams target)
        {

            m_target = target;
            m_destinationSock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            IPAddress serverAddr = IPAddress.Parse(m_target.m_ipAddress);
            m_destinationEndPoint = new IPEndPoint(serverAddr, m_target.m_ipPort);
        }

        public void SendMessageWithUDP(string message)
        {
            m_destinationSock.SendTo(Encoding.Unicode.GetBytes(message), m_destinationEndPoint);
        }

    }
}
