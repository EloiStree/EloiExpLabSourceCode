using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RelayPlayerIpMessageMono : MonoBehaviour
{

    public Eloi.PrimitiveUnityEvent_String m_messageRelay;
    public PlayerReceivedMessageEvent m_messageWithPlayerIpRelay;

    public void Push(PlayerReceivedMessage message)
    {
        m_messageWithPlayerIpRelay.Invoke(message);
        m_messageRelay.Invoke(message.m_unicodeText);
    }


}
