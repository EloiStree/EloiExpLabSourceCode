using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class UdpToClient_KillingGridMono : MonoBehaviour
{
    public Transform m_gridZone;
    public Space scaleType;
    public int m_count = 10;
    public LayerMask m_collisionLayer;
    public bool m_useSquareDebug;
    public bool m_useSquareDebugKill=true;
    public bool m_useSquareDebugSafe;

    public Vector3 m_botLeftDown;
    public Vector3 m_topRightUp;
    public Quaternion m_zoneDirection;


    public IEnumerator Start() {

        Vector3 scale = scaleType == Space.World ? m_gridZone.lossyScale : m_gridZone.localScale;
        Vector3 halfCubeVector = Vector3.zero;
        halfCubeVector.x = ( scale.x / 2f);
        halfCubeVector.y = ( scale.y / 2f);
        halfCubeVector.z = ( scale.z / 2f);
        halfCubeVector /= (float)m_count;
        Vector3 halfIniStep = halfCubeVector;
        while (true)
        {
            yield return new WaitForEndOfFrame();  
            for (int x = 0; x < m_count; x++)
            {
                for (int y = 0; y < m_count; y++)
                {
                    for (int z = 0; z < m_count; z++)
                    {
                        Vector3 center = halfIniStep;
                        center.x += halfCubeVector.x * 2 * (float)x;
                        center.y += halfCubeVector.y * 2 * (float)y;
                        center.z += halfCubeVector.z * 2 * (float)z;
                        center -= scale/2;
                        Eloi.E_RelocationUtility.GetLocalToWorld_Point(center, m_gridZone, out center);
                        //Eloi.E_DrawingUtility.DrawCartesianOrigine(center, Quaternion.identity, 0.1f, 1);
                        bool collision = Physics.OverlapBox(center, halfCubeVector , m_gridZone.rotation, m_collisionLayer).Length > 0;

                        //if (m_useSquareDebug && collision && m_useSquareDebugKill)
                        //    Eloi.E_DrawingUtility.DrawCube(Time.deltaTime, Color.red, center, m_gridZone.rotation, halfCubeVector);
                        //if (m_useSquareDebug && !collision && m_useSquareDebugSafe)
                        //    Eloi.E_DrawingUtility.DrawCube(Time.deltaTime, Color.green, center, m_gridZone.rotation, halfCubeVector);
                    }

                }

            }

      
        }


    }
    
}
