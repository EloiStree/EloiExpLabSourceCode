using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using UnityEngine;

[System.Serializable]
public class ListenToUdpPlayers 
{
    public delegate void UnicodeTextReceived(in string ipAddress, in string unicodeText);

    public bool m_threadMustDie = false;

    public int m_portObserved = 2507;
    public DateTime m_keepAliveTime;

    private UnicodeTextReceived m_onTextReceived;

    public void AddListener(UnicodeTextReceived listener)
    {
        m_onTextReceived = (UnicodeTextReceived)Delegate.Combine(m_onTextReceived, listener);
    }

    public void RemoveListener(UnicodeTextReceived listener)
    {
        m_onTextReceived = (UnicodeTextReceived)Delegate.Remove(m_onTextReceived, listener);
    }

    public ListenToUdpPlayers(System.Threading.ThreadPriority priority)
        : this(priority, 2507)
    {
    }
    Thread thread;
    public ListenToUdpPlayers(System.Threading.ThreadPriority priority, int portObserved)
    {
        m_portObserved = portObserved;
         thread = new Thread(StartThreadLoopListener);
        thread.Priority = priority;
        thread.Start();
        m_keepAliveTime = DateTime.Now;
    }

    ~ListenToUdpPlayers()
    {
        Kill();
    }

    public void Kill()
    {


        m_threadMustDie = true;

        if (thread != null)
            thread.Abort();
        
        if (udpClient!=null)
            udpClient.Close();
        if (udpClient != null)
            udpClient.Dispose();
    }
    UdpClient udpClient =null;
    public void StartThreadLoopListener()
    {
        
         udpClient = new UdpClient(m_portObserved);
        double seconds = (DateTime.Now - m_keepAliveTime).TotalSeconds;
        while (!m_threadMustDie && seconds<10.0)
        {
            IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, m_portObserved);
            byte[] bytes = udpClient.Receive(ref remoteEP);
            string address = remoteEP.Address.ToString();
            string unicodeText = Encoding.Unicode.GetString(bytes);
            if (m_onTextReceived != null)
            {
                m_onTextReceived(in address, in unicodeText);
            }

            Thread.Sleep(1);
        }

        udpClient.Close();
        udpClient.Dispose();
    }

    public void KeepAliveUpdateTime()
    {
        m_keepAliveTime = DateTime.Now;
    }
}
