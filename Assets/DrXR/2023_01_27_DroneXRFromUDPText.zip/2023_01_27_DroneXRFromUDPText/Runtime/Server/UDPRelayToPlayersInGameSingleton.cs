using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UDPRelayToPlayersInGameSingleton : MonoBehaviour
{
    public RelayMessageToPlayerMono m_playerInGame;
    public static UDPRelayToPlayersInGameSingleton m_instanceInScene;

    [TextArea(0,6)]
    public string m_lastSent;
    public void Awake()
    {
        m_instanceInScene = this;
    }
    public void PushMessageToPlayersUDP(string message)
    {
        if (m_instanceInScene!=null)
        {
            m_lastSent = message;
            m_playerInGame.GetAllIpInGame(out List<string> ips);
            DroneUDPToClients.SendUdp(message, ips.ToArray());
        }
    }
    public static  void PushMessageToPlayersUDPWithInstanceInScene(string message)
    {
        if (m_instanceInScene != null)
        {
            m_instanceInScene. m_lastSent = message;
           m_instanceInScene.  m_playerInGame.GetAllIpInGame(out List<string> ips);
            DroneUDPToClients.SendUdp(message, ips.ToArray());
        }
    }

}
