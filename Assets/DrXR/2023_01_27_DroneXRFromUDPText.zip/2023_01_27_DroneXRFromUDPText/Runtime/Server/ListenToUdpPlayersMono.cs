using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class ListenToUdpPlayersMono : MonoBehaviour
{
    public ListenToUdpPlayers m_listener;
    public int m_port =2509;
    public System.Threading.ThreadPriority m_threadPriority;

    public Queue<PlayerReceivedMessage> m_playerMessagesInQueue = new Queue<PlayerReceivedMessage>();
    public PlayerReceivedMessageEvent m_playerMessageOnUnityThread;

    void Start()
    {
        m_listener = new ListenToUdpPlayers(m_threadPriority, m_port);
        m_listener.AddListener(ListenToThread);
    }

    private void OnDestroy()
    {
        m_listener.RemoveListener(ListenToThread);
        m_listener.Kill();
    }
    public void OnApplicationQuit()
    {
        m_listener.Kill();
    }
    private void Update()
    {
        m_listener.KeepAliveUpdateTime();
        while (m_playerMessagesInQueue.Count>0) {
            m_playerMessageOnUnityThread.Invoke(m_playerMessagesInQueue.Dequeue());
        }
    }
   
    private void ListenToThread(in string ipAddress, in string unicodeText)
    {
        m_playerMessagesInQueue.Enqueue(new PlayerReceivedMessage(ipAddress, unicodeText));
    }

}

[System.Serializable]
public class PlayerReceivedMessageEvent : UnityEvent<PlayerReceivedMessage> { };



[System.Serializable]
public class PlayerReceivedMessage
{
    public string m_playerUniqueid;
    public string m_unicodeText;

    public PlayerReceivedMessage(string uniqueId, string unicodeText)
    {
        m_playerUniqueid = uniqueId;
        m_unicodeText = unicodeText;
    }
}