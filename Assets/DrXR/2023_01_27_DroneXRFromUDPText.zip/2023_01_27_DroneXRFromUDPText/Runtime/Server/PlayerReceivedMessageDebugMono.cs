using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerReceivedMessageDebugMono : MonoBehaviour
{
    public PlayerReceivedMessage m_message;
    public void Debug(PlayerReceivedMessage playerMesssage) {
        m_message = playerMesssage;
    }

}
