using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParserDrone_ChooseColorMono : MonoBehaviour
{
    public Eloi.ClassicUnityEvent_Color m_colorChanged;

    public void TryToParse(string message) {
        message = message.ToLower().Trim();
        if (message.IndexOf("color:")==0) {

            message = message.Replace("color:", "");
            Color c = Color.cyan;
            if (message == "red")   c = Color.red;
            if (message == "blue")  c = Color.blue;
            if (message == "green") c = Color.green;
            if (message == "black") c = Color.black;
            if (message == "white") c = Color.white;
            Eloi.E_ColorUtility.ConvertHashFFFFFFFFToColor(in message, out bool converted, out Color tc);
            if (converted)
                c = tc;
            m_colorChanged.Invoke(c);
          

        }
    }
}
