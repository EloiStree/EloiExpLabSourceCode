using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using UnityEngine;

public class UI_DisplayServerIP : MonoBehaviour
{
    public string m_port = "2509";
    public Eloi.PrimitiveUnityEvent_String m_ipOfServer;
    public Eloi.PrimitiveUnityEvent_String m_portOfServerOfServer;


    public void Awake()
    {
        var addresses = Dns.GetHostEntryAsync((Dns.GetHostName()))
                .Result
                .AddressList
                .Where(x => x.AddressFamily == AddressFamily.InterNetwork)
                .Select(x => x.ToString())
                .ToArray();
        m_ipOfServer.Invoke(string.Join(" | ",addresses));
        m_portOfServerOfServer.Invoke(m_port);

    }


}
