# 2022_10_24_UDPPusherOmiDLLUnity
Unity wrapper of the UDP pusher DLL that allows to communicate between apps and unity.


DLL linked: https://github.com/EloiStree/2022_10_23_UDPPusherOmiDLL
